package main;

public class CricketGame {
    public static void main(String[] args) {
        GameEngine game = new GameEngine();
        game.start();
    }
}