package main;

public class Utils {
    public static void printLine() {
        System.out.println("---------------------------------------------");
    }
}
